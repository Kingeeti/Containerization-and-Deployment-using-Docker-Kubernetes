const API_URL = '/api';

document.addEventListener('DOMContentLoaded', fetchTasks);

// Enable enter key to submit
document.getElementById('taskInput').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        addTask();
    }
});

async function fetchTasks() {
    try {
        const response = await fetch(`${API_URL}/todos`);
        if (!response.ok) throw new Error('Network response was not ok');
        const tasks = await response.json();
        const taskList = document.getElementById('taskList');
        taskList.innerHTML = '';
        
        if (tasks.length === 0) {
            taskList.innerHTML = '<li style="color: #999; justify-content: center;">No tasks yet. Add one!</li>';
            return;
        }

        tasks.forEach(task => {
            const li = document.createElement('li');
            
            const textSpan = document.createElement('span');
            textSpan.className = 'task-text';
            textSpan.textContent = task.task;

            li.appendChild(textSpan);
            taskList.appendChild(li);
        });
    } catch (error) {
        console.error('Error fetching tasks:', error);
        const taskList = document.getElementById('taskList');
        taskList.innerHTML = `<li style="color: #e74c3c; justify-content: center;">Error loading tasks. Is the backend running?</li>`;
    }
}

async function addTask() {
    const taskInput = document.getElementById('taskInput');
    const task = taskInput.value.trim();
    if (!task) return;

    // Optional visual feedback during network request
    taskInput.disabled = true;

    try {
        const response = await fetch(`${API_URL}/todos`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ task })
        });
        
        if (response.ok) {
            taskInput.value = '';
            fetchTasks();
        } else {
            console.error('Failed to add task');
        }
    } catch (error) {
        console.error('Error adding task:', error);
        alert('Failed to connect to the server.');
    } finally {
        taskInput.disabled = false;
        taskInput.focus();
    }
}
