import os
from flask import Flask, jsonify, request
from flask_cors import CORS
from pymongo import MongoClient
import urllib.parse
import logging

app = Flask(__name__)
CORS(app)
logging.basicConfig(level=logging.INFO)

mongo_user = os.environ.get('MONGO_INITDB_ROOT_USERNAME', 'root')
mongo_pass = os.environ.get('MONGO_INITDB_ROOT_PASSWORD', 'example')
mongo_host = os.environ.get('MONGO_HOST', 'mongodb')
mongo_port = os.environ.get('MONGO_PORT', '27017')
mongo_db   = os.environ.get('MONGO_DB', 'tododb')

escaped_user = urllib.parse.quote_plus(mongo_user)
escaped_pass = urllib.parse.quote_plus(mongo_pass)

# Connect to MongoDB
try:
    mongo_uri = f"mongodb://{escaped_user}:{escaped_pass}@{mongo_host}:{mongo_port}/?authSource=admin"
    client = MongoClient(mongo_uri, serverSelectionTimeoutMS=5000)
    db = client[mongo_db]
    todos_collection = db['todos']
    logging.info(f"Connected to MongoDB at {mongo_host}:{mongo_port}")
except Exception as e:
    logging.error(f"Failed to connect to MongoDB: {e}")

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "healthy"}), 200

@app.route('/api/todos', methods=['GET'])
def get_todos():
    try:
        todos = []
        for todo in todos_collection.find():
            todos.append({
                "id": str(todo['_id']),
                "task": todo['task'],
                "completed": todo.get('completed', False)
            })
        return jsonify(todos), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/todos', methods=['POST'])
def add_todo():
    try:
        data = request.json
        if not data or 'task' not in data:
            return jsonify({"error": "Missing task"}), 400
        
        new_todo = {
            "task": data['task'],
            "completed": False
        }
        result = todos_collection.insert_one(new_todo)
        new_todo['id'] = str(result.inserted_id)
        del new_todo['_id']
        
        return jsonify(new_todo), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
